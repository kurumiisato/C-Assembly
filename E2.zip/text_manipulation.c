#include <stdio.h>
#include <string.h>
#include "text_manipulation.h"

int remove_spaces(const char *source, char *result, int *num_spaces_removed) {
  int i, index = 0, end, start, last;
  int length = strlen(source);
  *num_spaces_removed = 0;

  if (length == 0 || source == NULL || num_spaces_removed == NULL) {
    /*Result does not change*/
    return FAILURE;
  }

  /* Find where the last space is */
  while (source[index] != '\0') {
    index++;
    last = index;
  }

  /* Count the first half of spaces */
  index = 0;
  while (source[index] == ' ') {
    (*num_spaces_removed)++;
    index++;
  }

  start = index;
  index = last;

  while (source[index - 1] == ' ') {
    (*num_spaces_removed)++;
    index--;
  }
  /* End of phrase is the current index */
  end = index;

  /* Start of phrase*/
  index = start;

  /* Length of phrase*/
  length = end - start;
 
  /* Go through phrase */ 
  for (i = 0; i < length; i++) {
     result[i] = source[start + i];
  }

  return SUCCESS;
}

/* Center */
int center(const char *source, int width, char *result) {
  int length, i, spaces = 0, index = 0;
  length = strlen(source);
  spaces = (width - length) / 2;
  
  while (index < spaces) {
    result[index] = ' ';
    index++;
  }
  
  for (i = 0; i < length; i++) {
    result[i + spaces] = source[i];
  }
 
  for (i = 0; i < spaces; i++) {
    result[length + spaces] = ' ';
  }
  
  if (source == NULL || strlen(source) == 0 || width < length) {
    /*Result does not change*/
    return FAILURE;
  }
  
  return SUCCESS;
}
