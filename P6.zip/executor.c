/* Kurumi Sato
   117185836 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <err.h>
#include <sysexits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/wait.h>
#include "command.h"
#include "executor.h"

/* static void print_tree(struct tree *t);*/

int execute(struct tree *t) {
  pid_t pid, child_one_pid, child_two_pid;
  int status;
  int output_fd, input_fd;
  int pipes[2];

  if (t == NULL) {
    return 0;
  }

  /* If it is a leaf */
  if (t->conjunction == NONE) {
    /* If the command is cd*/
    if (strcmp(t->argv[0], "cd") == 0) {
      /* If no arguments given, change directory to home*/
      if (t->argv[1] == NULL) {
        chdir(getenv("HOME"));
	/* If directory is given, go to that one */
      } else {
	status = chdir(t->argv[1]);
	if (status) {
	  perror(t->argv[1]);
	}
      }
    } else if (strcmp(t->argv[0], "exit")) {
      exit(0);
      /* Deal with other commands */
    } else {
      if ((pid = fork()) < 0) {
	perror("fork error");
      }
      if (pid) {
	wait(&status);
	return status;

      } else { 
	/*If input file is redirected to that file*/
	if (t->input != NULL) {
	  input_fd = open(t->input, O_RDONLY);
	  if(input_fd < 0) {
	    err(EX_OSERR, "error in opening file");
	  } else if (dup2(input_fd, STDIN_FILENO) < 0) {
	    err(EX_OSERR, "dup2 error");
	  } else if (close(input_fd) < 0) {
	    err(EX_OSERR, "error in closing file");
	  }
	}
	/* If output is redirected to that file */
	if (t->output != NULL) {
	  output_fd = open(t->output, O_RDWR | O_CREAT | O_TRUNC, 0664);
	  if (output_fd < 0) {
	    perror("error opening file");
	  } else if (dup2(output_fd, STDOUT_FILENO) < 0) {
	    perror("dup 2 error");
	  } else if (close(output_fd) < 0) {
	    perror("error closing file");
	  }
	}
	execvp(t->argv[0], t->argv);
        printf("Failed to execute %s\n", t->argv[0]);
	fflush(NULL);
      }
    }
  } else if (t->conjunction == PIPE) {
    pipe(pipes); /* Pipe */
    child_one_pid = fork(); /* Fork */

    /* Child 1's code*/
    if(child_one_pid == 0) {
      /* We don't need pipe's read end */
      close(pipes[0]);
      /* Redirect standard output to pipe write end then close right end*/
      if (dup2(pipes[1], STDOUT_FILENO) < 0) {
	perror("dup2 failed");
      }
      close(pipes[1]);

      /* Load and execute */
      execlp(t->input, t->output, NULL);
      err(EX_OSERR, "exec error");

      /* Parent code */
    } else {
      /* Create second child */
      child_two_pid = fork();
      /* Child 2's code */
      if (child_two_pid  == 0) {
	/* Close the write end of pipe */
	close(pipes[1]);
	/* Reidrect standard input to pipe read end and then close read end */
	dup2(pipes[0], STDIN_FILENO);
	close(pipes[0]);
	/* Execute and load */
	execlp("", "", NULL);
	err(EX_OSERR, "exec error");

      } else { /* Parent has no need for pipe */
	close(pipes[0]);
	close(pipes[1]);
	/* Reap both children */
	wait(NULL);
	wait(NULL);
      }
    }

    return 0;

    /* If the conjunction is AND */
  } else if (t->conjunction == AND ){

    status = execute(t->left);

    /* If left subtree is executed successfully, process right tree */
    if (status == 0) {
      return execute(t->right);
      /* If left execution failed, return the failed status */
    } else {
      return status;
    }

  } else if (t->conjunction == SUBSHELL) {
    if (t->input) {
      if ((input_fd = open(t->input, O_RDONLY)) < 0) {
	perror("subshell, cannot open input file");
      }
    } 
    if(t->output) {
      if((output_fd = open(t->output, O_WRONLY | O_CREAT | O_TRUNC, 0664)) < 0){
	perror("subshell, cannot close input file");
      }
    }
    if ((pid = fork()) < 0) {
      perror("fork error");
    } else if (pid) {
      execute(t->left);
      exit(0);
    } else {
      wait(NULL);
    }
  } 
  fflush(NULL);
  return 0;
}

/*
static void print_tree(struct tree *t) {
   if (t != NULL) {
      print_tree(t->left);

      if (t->conjunction == NONE) {
         printf("NONE: %s, ", t->argv[0]);
      } else {
         printf("%s, ", conj[t->conjunction]);
      }
      printf("IR: %s, ", t->input);
      printf("OR: %s\n", t->output);

      print_tree(t->right);
   }
}

*/
